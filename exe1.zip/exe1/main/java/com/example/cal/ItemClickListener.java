package com.example.cal;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view, int postion, boolean isLongClick);

}
