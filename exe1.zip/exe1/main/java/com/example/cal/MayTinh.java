package com.example.cal;

public class MayTinh {
    String kq;

    public MayTinh() {
    }

    public MayTinh(String kq) {
        this.kq = kq;
    }

    public String getKq() {
        return kq;
    }

    public void setKq(String kq) {
        this.kq = kq;
    }
}
