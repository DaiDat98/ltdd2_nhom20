package com.example.projectnhom20.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.projectnhom20.Database.DBChamThi;
import com.example.projectnhom20.GiaoDien.ActivitySuaBT;
import com.example.projectnhom20.Model.ChamThi;
import com.example.projectnhom20.R;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CustomAdapterTTCT extends RecyclerView.Adapter<CustomAdapterTTCT.MyViewHolder> implements Filterable {
    private Context context;
    private Activity activity;
    private ArrayList<ChamThi> data;
    private ArrayList<ChamThi> dataArrayList;

    private DBChamThi myDB;

    public CustomAdapterTTCT(Activity activity, Context context, ArrayList<ChamThi> data){
        this.activity = activity;
        this.context = context;
        this.data = data;
        this.dataArrayList=data;
        myDB = new DBChamThi(context);
    }

    @NonNull
    @Override
    public CustomAdapterTTCT.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.item_recyclerview_bt, parent, false);
        return new CustomAdapterTTCT.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapterTTCT.MyViewHolder holder, final int position) {
        final ChamThi ct = data.get(position);
        holder.tvIDDH.setText(String.valueOf(ct.getSttCT()));
        holder.tvMaDH.setText(String.valueOf(ct.getSophieu()));
        holder.tvMaKH.setText(String.valueOf(ct.getMaGV()));
        holder.tvMaSP.setText(String.valueOf(ct.getMaMH()));
        holder.tvSoLuongSPDat.setText(String.valueOf(ct.getSoLuongBaiThi()));
        holder.tvNgayTao.setText(String.valueOf(ct.getNgayChamThi()));
        holder.tvTinhTrangDH.setText(String.valueOf(ct.getTinhTrangBaiThi()));

        holder.recyclerViewItemLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ActivitySuaBT.class);
                intent.putExtra("id",Integer.valueOf(ct.getSttCT()));
                intent.putExtra("maDH", String.valueOf(ct.getSophieu()));
                intent.putExtra("maKH", String.valueOf(ct.getMaGV()));
                intent.putExtra("maSP", String.valueOf(ct.getMaMH()));
                intent.putExtra("soLuongSPDat", Integer.valueOf(ct.getSoLuongBaiThi()));
                intent.putExtra("ngayTaoDH", String.valueOf(ct.getNgayChamThi()));
                intent.putExtra("tinhTrangDH", String.valueOf(ct.getTinhTrangBaiThi()));
                activity.startActivityForResult(intent,1);
            }
        });
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    data = dataArrayList;
                } else {
                    ArrayList<ChamThi> filteredList = new ArrayList<>();
                    for (ChamThi dh : dataArrayList) {

                        if (dh.getSophieu().toLowerCase().contains(charString)) {

                            filteredList.add(dh);
                        }
                    }
                    data = filteredList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = data;
                return filterResults;
            }

            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                data = (ArrayList<ChamThi>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvIDDH, tvMaDH, tvMaKH, tvMaSP, tvSoLuongSPDat, tvNgayTao, tvTinhTrangDH;
        LinearLayout recyclerViewItemLayout;
        ImageView imgDH;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imgDH = itemView.findViewById(R.id.imgRecyclerViewIDDH);
            tvIDDH = itemView.findViewById(R.id.tvRecyclerViewIDDH);
            tvMaDH = itemView.findViewById(R.id.tvMaDH);
            tvMaKH = itemView.findViewById(R.id.tvMaKHDH);
            tvMaSP = itemView.findViewById(R.id.tvMaSPDH);
            tvSoLuongSPDat = itemView.findViewById(R.id.tvSoLuong);
            tvNgayTao = itemView.findViewById(R.id.tvNgayTaoDH);
            tvTinhTrangDH = itemView.findViewById(R.id.tvTinhTrangDH);

            recyclerViewItemLayout = itemView.findViewById(R.id.recyclerViewItemLayoutDH);
            //Animate Recyclerview
            //Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            //recyclerViewItemLayoutKH.setAnimation(translate_anim);
        }
    }
}
