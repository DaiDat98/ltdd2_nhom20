package com.example.projectnhom20.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import com.example.projectnhom20.Model.ChamThi;
import com.example.projectnhom20.Model.GiaoVien;
import com.example.projectnhom20.Model.MonHoc;

import java.util.ArrayList;

public class DBChamThi {
    DBHelper dbHelper;
    Context context;
    public DBChamThi(Context context) {
        dbHelper= new DBHelper(context);
        this.context = context;
    }

    //--------------------------------------Table Gi---------------------------------------------------
    public ArrayList<GiaoVien> listGiaoViens(){
        String sql = "select * from " + "QLKH";
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        ArrayList<GiaoVien> giaoViens = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, null);
        if(cursor.moveToFirst()){
            do{
                Integer _id = (cursor.getInt(0));
                String maKH = cursor.getString(1);
                String tenKH = cursor.getString(2);
                String diaChi = cursor.getString(3);
                String soDT = cursor.getString(4);
                giaoViens.add(new GiaoVien(_id,maKH,tenKH,diaChi,soDT));
            }while (cursor.moveToNext());
        }
        cursor.close();
        return giaoViens;
    }

    public void ThemKH(GiaoVien giaoVien){
        ContentValues values = new ContentValues();
        values.put("makh", giaoVien.getMaGV());
        values.put("tenkh", giaoVien.getTenGV());
        values.put("diachi", giaoVien.getDiaChi());
        values.put("sodt", giaoVien.getSoDT());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.insert("QLKH", null, values);
    }

    public void SuaKH(GiaoVien giaoVien){
        ContentValues values = new ContentValues();
        values.put("makh", giaoVien.getMaGV());
        values.put("tenkh", giaoVien.getTenGV());
        values.put("diachi", giaoVien.getDiaChi());
        values.put("sodt", giaoVien.getSoDT());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.update("QLKH", values, "_id"	+ "	= ?", new String[]{String.valueOf(giaoVien.getSttGV())});
    }

    public void XoaMotItemKH(GiaoVien giaoVien){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long result = db.delete("QLKH", "_id=?", new String[]{String.valueOf(giaoVien.getSttGV())});
        if(result == -1){
            Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Đã xóa.", Toast.LENGTH_SHORT).show();
        }
    }

    public void XoaTatCaKH(){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DELETE FROM " + "QLKH");
        //RESET STT ID TỰ TĂNG
        db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" + "QLKH" + "'");
    }

    public long XoaItemTheoIDKH(int id)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        return db.delete("QLKH", "_id=?", new String[]{String.valueOf(id)});
    }

    public ArrayList<String> getAllGiaoViens(){
        ArrayList<String> listMaSoKH = new ArrayList<String>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        db.beginTransaction();

        try {
            String selectQuery = "SELECT * FROM " + "QLKH";
            Cursor cursor = db.rawQuery(selectQuery, null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String khID = cursor.getString(cursor.getColumnIndex("makh"));
                    listMaSoKH.add(khID);
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e)  {
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }
        return listMaSoKH;
    }

    //--------------------------------------Table Sản Phẩm---------------------------------------------------
    public ArrayList<MonHoc> listMonHocs(){
        String sql = "select * from " + "QLSP";
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        ArrayList<MonHoc> monHocs = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, null);
        if(cursor.moveToFirst()){
            do{
                Integer _id = (cursor.getInt(0));
                String maSP = cursor.getString(1);
                String tenSP = cursor.getString(2);
                String xuatXu = cursor.getString(3);
                String donGia = cursor.getString(4);
                byte[] anhSanPham = cursor.getBlob(5);
                monHocs.add(new MonHoc(_id,maSP,tenSP,xuatXu,donGia, anhSanPham));
            }while (cursor.moveToNext());
        }
        cursor.close();
        return monHocs;
    }

    public void ThemSP(MonHoc monHoc){
        ContentValues values = new ContentValues();
        values.put("masp", monHoc.getMaMH());
        values.put("tensp", monHoc.getTenMH());
        values.put("xuatxu", monHoc.getKhoa());
        values.put("dongia", monHoc.getChiphi());
        values.put("imagesp", monHoc.getImageMH());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.insert("QLSP", null, values);
    }

    public void SuaSP(MonHoc monHoc){
        ContentValues values = new ContentValues();
        values.put("masp", monHoc.getMaMH());
        values.put("tensp", monHoc.getTenMH());
        values.put("xuatxu", monHoc.getKhoa());
        values.put("dongia", monHoc.getChiphi());
        values.put("imagesp", monHoc.getImageMH());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.update("QLSP", values, "_id"	+ "	= ?", new String[]{String.valueOf(monHoc.getSttSP())});
    }

    public void XoaMotItemSP(MonHoc monHoc){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long result = db.delete("QLSP", "_id=?", new String[]{String.valueOf(monHoc.getSttSP())});
        if(result == -1){
            Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Đã xóa.", Toast.LENGTH_SHORT).show();
        }
    }

    public void XoaTatCaSP(){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DELETE FROM " + "QLSP");
        //RESET STT ID TỰ TĂNG
        db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" + "QLSP" + "'");
    }

    public ArrayList<String> getAllMonHocs(){
        ArrayList<String> listMaSoSP = new ArrayList<String>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        db.beginTransaction();

        try {
            String selectQuery = "SELECT * FROM " + "QLSP";
            Cursor cursor = db.rawQuery(selectQuery, null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String spID = cursor.getString(cursor.getColumnIndex("masp"));
                    listMaSoSP.add(spID);
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e)  {
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }
        return listMaSoSP;
    }

    //--------------------------------------Table Đơn hàng---------------------------------------------------
    public ArrayList<ChamThi> listDonHangs(){
        String sql = "select * from " + "QLDH";
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        ArrayList<ChamThi> chamThis = new ArrayList<>();
        Cursor cursor = db.rawQuery(sql, null);
        if(cursor.moveToFirst()){
            do{
                Integer _id = (cursor.getInt(0));
                String maDH = cursor.getString(1);
                String maKHDH = cursor.getString(2);
                String maSPDH = cursor.getString(3);
                Integer soLuongDat = cursor.getInt(4);
                String ngayTaoDH = cursor.getString(5);
                String tinhTrangDH = cursor.getString(6);
                chamThis.add(new ChamThi(_id,maDH,maKHDH,maSPDH,soLuongDat, ngayTaoDH, tinhTrangDH));
            }while (cursor.moveToNext());
        }
        cursor.close();
        return chamThis;
    }

    public void ThemDH(ChamThi chamThi){
        ContentValues values = new ContentValues();
        values.put("madh", chamThi.getSophieu());
        values.put("makh", chamThi.getMaGV());
        values.put("masp", chamThi.getMaMH());
        values.put("soluongdat", chamThi.getSoLuongBaiThi());
        values.put("ngaytaodh", chamThi.getNgayChamThi());
        values.put("tinhtrangdh", chamThi.getTinhTrangBaiThi());

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.insert("QLDH", null, values);
    }

    public void SuaBT(ChamThi chamThi){
        ContentValues values = new ContentValues();
        values.put("madh", chamThi.getSophieu());
        values.put("makh", chamThi.getMaGV());
        values.put("masp", chamThi.getMaMH());
        values.put("soluongdat", chamThi.getSoLuongBaiThi());
        values.put("ngaytaodh", chamThi.getNgayChamThi());
        values.put("tinhtrangdh", chamThi.getTinhTrangBaiThi());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.update("QLDH", values, "_id"	+ "	= ?", new String[]{String.valueOf(chamThi.getSttCT())});
    }

    public void XoaMotItemDH(ChamThi chamThi){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long result = db.delete("QLDH", "_id=?", new String[]{String.valueOf(chamThi.getSttCT())});
        if(result == -1){
            Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Đã xóa.", Toast.LENGTH_SHORT).show();
        }
    }

    public void XoaTatCaDH(){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("DELETE FROM " + "QLDH");
        //RESET STT ID TỰ TĂNG
        db.execSQL("DELETE FROM SQLITE_SEQUENCE WHERE NAME = '" + "QLDH" + "'");
    }

    public ArrayList<String> getAllsTinhTrangCT(){
        ArrayList<String> listTinhTrangDH = new ArrayList<String>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        db.beginTransaction();

        try {
            String selectQuery = "SELECT * FROM " + "QLTINHTRANGDH";
            Cursor cursor = db.rawQuery(selectQuery, null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String dhTinhTrang = cursor.getString(cursor.getColumnIndex("tinhtrangdh"));
                    listTinhTrangDH.add(dhTinhTrang);
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e)  {
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }
        return listTinhTrangDH;
    }

    public int getSLDonHangHoanThanh() {
        String countQuery = "SELECT * " + "FROM " + "QLDH " + "WHERE " + "tinhtrangdh = " + "'Đã hoàn thành'";

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public int getSLDonHangDangGiao() {
        String countQuery = "SELECT * " + "FROM " + "QLDH " + "WHERE " + "tinhtrangdh = " + "'Đang Chấm'";

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public int getSLDonHangDaHuy() {
        String countQuery = "SELECT * " + "FROM " + "QLDH " + "WHERE " + "tinhtrangdh = " + "'Đã hủy'";

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }

    public int getSLDonHangTong() {
        String countQuery = "SELECT * " + "FROM " + "QLDH ";

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }


}
