package com.example.projectnhom20.GiaoDien;


import android.app.Activity;
import android.os.Bundle;

import com.example.projectnhom20.R;

public class ActivityAboutUs extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.abotus);


    }
}
