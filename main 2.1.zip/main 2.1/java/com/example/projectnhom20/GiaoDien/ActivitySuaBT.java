package com.example.projectnhom20.GiaoDien;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.projectnhom20.Adapter.SpinnerAdapterMH;
import com.example.projectnhom20.Database.DBChamThi;
import com.example.projectnhom20.Model.ChamThi;
import com.example.projectnhom20.Model.MonHoc;
import com.example.projectnhom20.R;

import java.util.ArrayList;

public class ActivitySuaBT extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText edtSoPhieu, edtSoLuongBT, edtNgayCham;
    Spinner spinnerMaGV, spinnerMaMH, spinnerTinhTrangBT;
    Button btnLuuBT, btnXoaBT;
    DBChamThi myDB;
    private String maBT = "";
    private String clickedMaMH = "";
    private String tinhTrangBT = "";
    ChamThi chamThi = new ChamThi();
    private ArrayList<String> arrGV = new ArrayList<>();
    private ArrayList<String> arrMH = new ArrayList<>();
    private ArrayList<String> arrTinhTrangBT = new ArrayList<>();
    private SpinnerAdapterMH spinnerAdapterMH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_bt);
        setControl();
        setEvent();
        layDuLieuDH();

        //Lấy tên cho trang details
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            String titleFormEditDH = ActivitySuaBT.this.getResources().getString(R.string.titleFormEditDH);
            ab.setTitle(titleFormEditDH + " " +  chamThi.getSophieu());
        }
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    private void setEvent() {
        spinnerMaGV.setOnItemSelectedListener(this);
        spinnerMaMH.setOnItemSelectedListener(this);
        spinnerTinhTrangBT.setOnItemSelectedListener(this);
        loadSpinnerData();
        btnLuuBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaBaiThiVaoMang();
            }
        });

        btnXoaBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmXoa();
            }
        });
    }
    private void loadSpinnerData() {
        myDB = new DBChamThi(getApplicationContext());
        //Set giá trị cho spinner Mã GV
        arrGV = myDB.getAllGiaoViens();
        ArrayAdapter<String> adapterMaGV = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arrGV);
        adapterMaGV.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMaGV.setAdapter(adapterMaGV);

        //Set giá trị cho spinner Mã SP
        ArrayList<MonHoc> listMaMH = myDB.listMonHocs();
        spinnerAdapterMH = new SpinnerAdapterMH(this, listMaMH);
        spinnerMaMH.setAdapter(spinnerAdapterMH);

        //Set giá trị cho spinner tình trạng bài chấm thi
        arrTinhTrangBT = myDB.getAllsTinhTrangCT();
        ArrayAdapter<String> adapterTinhTrangCT = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arrTinhTrangBT);
        adapterTinhTrangCT.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTinhTrangBT.setAdapter(adapterTinhTrangCT);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Spinner spinner = (Spinner) parent;
        if(spinner.getId() == R.id.suaSpinnerMaKH) {
            maBT = parent.getItemAtPosition(position).toString();
//            Toast.makeText(parent.getContext(), "You selected: " + maKH, Toast.LENGTH_LONG).show();
        } else if (spinner.getId() == R.id.suaSpinnerMaSP) {
            MonHoc maSP = (MonHoc) parent.getItemAtPosition(position);
            clickedMaMH = maSP.getMaMH();
//            Toast.makeText(parent.getContext(), "You selected: " + maSP, Toast.LENGTH_LONG).show();
        } else if (spinner.getId() == R.id.suaSpinnerTinhTrangDH) {
            tinhTrangBT = parent.getSelectedItem().toString();
            Toast.makeText(parent.getContext(), "You selected: " + tinhTrangBT,
                    Toast.LENGTH_LONG).show();
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // TODO Auto-generated method stub
    }

    private void suaBaiThiVaoMang() {
        myDB =  new DBChamThi(this);
        try {
            final String maBT = edtSoPhieu.getText().toString();
            final Integer soLuongBT = Integer.parseInt(edtSoLuongBT.getText().toString());
            final String ngayCham = edtNgayCham.getText().toString();

            if(TextUtils.isEmpty(maBT) || TextUtils.isEmpty(this.maBT) || TextUtils.isEmpty(clickedMaMH)|| TextUtils.isEmpty(ngayCham)){
                String toastNull = ActivitySuaBT.this.getResources().getString(R.string.alertNull);
                Toast.makeText(ActivitySuaBT.this, toastNull, Toast.LENGTH_LONG).show();
            }
            else{
                String toastSuccess = ActivitySuaBT.this.getResources().getString(R.string.alertSuccess);
                myDB.SuaBT(new ChamThi(chamThi.getSttCT(),maBT, this.maBT, clickedMaMH,soLuongBT,ngayCham, tinhTrangBT));
                Toast.makeText(ActivitySuaBT.this, toastSuccess, Toast.LENGTH_LONG).show();
            }

        }catch (NumberFormatException nfe) {
            String toastNull = ActivitySuaBT.this.getResources().getString(R.string.alertNull);
            Toast.makeText(ActivitySuaBT.this, toastNull, Toast.LENGTH_LONG).show();
        }
    }

    //Lấy dữ liệu đổ vào trang sửa khi click vào item
    void layDuLieuDH(){
        //Gọi array từ DB để lấy ID của Khách hàng và Sản Phẩm
        arrGV = myDB.getAllGiaoViens();
        arrMH = myDB.getAllMonHocs();
        arrTinhTrangBT = myDB.getAllsTinhTrangCT();

        if(getIntent().hasExtra("id") && getIntent().hasExtra("maDH")
                && getIntent().hasExtra("maKH") && getIntent().hasExtra("maSP")
                && getIntent().hasExtra("soLuongSPDat") && getIntent().hasExtra("ngayTaoDH")){
            //Getting Data from Intent
            int id = -1;
            int soLuongBT = -1;
            chamThi.setSttCT(getIntent().getIntExtra("id",id));
            chamThi.setSophieu(getIntent().getStringExtra("maDH"));
            chamThi.setMaGV(getIntent().getStringExtra("maKH"));
            chamThi.setMaMH(getIntent().getStringExtra("maSP"));
            chamThi.setSoLuongBaiThi(getIntent().getIntExtra("soLuongSPDat",soLuongBT));
            chamThi.setNgayChamThi(getIntent().getStringExtra("ngayTaoDH"));
            chamThi.setTinhTrangBaiThi(getIntent().getStringExtra("tinhTrangDH"));
            //Setting Intent Data
            edtSoPhieu.setText(chamThi.getSophieu());
            spinnerMaGV.setSelection(arrGV.indexOf(chamThi.getMaGV()));
            spinnerMaMH.setSelection(arrMH.indexOf(chamThi.getMaMH()));
            edtSoLuongBT.setText(String.valueOf(chamThi.getSoLuongBaiThi()));
            edtNgayCham.setText(chamThi.getNgayChamThi());
            spinnerTinhTrangBT.setSelection(arrTinhTrangBT.indexOf(chamThi.getTinhTrangBaiThi()));
        } else {
            String toastMessage = ActivitySuaBT.this.getResources().getString(R.string.noData);
            Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show();
        }
    }

    //Method nút xóa
    void confirmXoa() {
        String toastTittle = ActivitySuaBT.this.getResources().getString(R.string.confirmDeleteTitle);
        String toastMessage = ActivitySuaBT.this.getResources().getString(R.string.confirmDeleteMessage);
        String toastYes = ActivitySuaBT.this.getResources().getString(R.string.confirmYes);
        String toastNo = ActivitySuaBT.this.getResources().getString(R.string.confirmNo);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(toastTittle + chamThi.getSophieu());
        builder.setMessage(toastMessage + chamThi.getSophieu());
        builder.setPositiveButton(toastYes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DBChamThi myDB = new DBChamThi(ActivitySuaBT.this);
                myDB.XoaMotItemDH(chamThi);
                finish();
            }
        });
        builder.setNegativeButton(toastNo, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        builder.create().show();
    }

    private void setControl() {
        edtSoPhieu = findViewById(R.id.suaMaDH);
        spinnerMaGV = findViewById(R.id.suaSpinnerMaKH);
        spinnerMaMH = findViewById(R.id.suaSpinnerMaSP);
        spinnerTinhTrangBT = findViewById(R.id.suaSpinnerTinhTrangDH);
        edtSoLuongBT = findViewById(R.id.suaSoLuongSP);
        edtNgayCham = findViewById(R.id.suaNgayTaoDH);
        btnLuuBT = findViewById(R.id.save_button_dh);
        btnXoaBT = findViewById(R.id.delete_button_dh);
    }
    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    //Bấm nút quay về trang danh sách (ko dùng AndroidManifest được vì là từ Fragment về Activity)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
}