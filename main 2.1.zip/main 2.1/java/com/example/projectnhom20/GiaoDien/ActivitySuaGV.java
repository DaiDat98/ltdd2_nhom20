package com.example.projectnhom20.GiaoDien;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projectnhom20.Database.DBChamThi;
import com.example.projectnhom20.Model.GiaoVien;
import com.example.projectnhom20.R;

public class ActivitySuaGV extends AppCompatActivity {

    EditText edtMaGV, edtTenGV, edtDiaChi, edtSoDT;
    Button btnLuu, btnXoa;

    GiaoVien giaoVien = new GiaoVien();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_gv);
        setControl();
        setEvent();
        layDuLieuGV();

        //Lấy tên cho trang details
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            String titleFormEditGV = ActivitySuaGV.this.getResources().getString(R.string.titleFormEditKH);
            ab.setTitle(titleFormEditGV + " " +  giaoVien.getMaGV());
        }

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    private void setEvent() {
        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaGiaoVienVaoMang();
            }
        });

        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmXoa();
            }
        });
    }

    private void suaGiaoVienVaoMang() {
        DBChamThi myDB =  new DBChamThi(this);
        final String maGV = edtMaGV.getText().toString();
        final String tenGV = edtTenGV.getText().toString();
        final String diaChi = edtDiaChi.getText().toString();
        final String soDT = edtSoDT.getText().toString();

        if(TextUtils.isEmpty(maGV) || TextUtils.isEmpty(tenGV) || TextUtils.isEmpty(diaChi)|| TextUtils.isEmpty(soDT)){
            String toastNull = ActivitySuaGV.this.getResources().getString(R.string.alertNull);
            Toast.makeText(ActivitySuaGV.this, toastNull, Toast.LENGTH_LONG).show();
        }
        else{
            String toastSuccess = ActivitySuaGV.this.getResources().getString(R.string.alertSuccess);
            myDB.SuaKH(new GiaoVien(giaoVien.getSttGV(),maGV,tenGV,diaChi,soDT));
            Toast.makeText(ActivitySuaGV.this, toastSuccess, Toast.LENGTH_LONG).show();
        }
    }

    //Lấy dữ liệu đổ vào trang sửa khi click vào item
    void layDuLieuGV(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("maKH") &&
                getIntent().hasExtra("tenKH") &&
                getIntent().hasExtra("diaChi") && getIntent().hasExtra("soDT")){
            //Getting Data from Intent
            int id = -1;
            giaoVien.setSttGV(getIntent().getIntExtra("id",id));
            giaoVien.setMaGV(getIntent().getStringExtra("maKH"));
            giaoVien.setTenGV(getIntent().getStringExtra("tenKH"));
            giaoVien.setDiaChi(getIntent().getStringExtra("diaChi"));
            giaoVien.setSoDT(getIntent().getStringExtra("soDT"));

            //Setting Intent Data
            edtMaGV.setText(giaoVien.getMaGV());
            edtTenGV.setText(giaoVien.getTenGV());
            edtDiaChi.setText(giaoVien.getDiaChi());
            edtSoDT.setText(giaoVien.getSoDT());
            Log.d("TranVan", giaoVien.getMaGV()+" "+ giaoVien.getTenGV()+" "+ giaoVien.getDiaChi()+ " " + giaoVien.getSoDT());
        } else {
            String toastMessage = ActivitySuaGV.this.getResources().getString(R.string.noData);
            Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show();
        }
    }

    void confirmXoa() {
        String toastTittle = ActivitySuaGV.this.getResources().getString(R.string.confirmDeleteTitle);
        String toastMessage = ActivitySuaGV.this.getResources().getString(R.string.confirmDeleteMessage);
        String toastYes = ActivitySuaGV.this.getResources().getString(R.string.confirmYes);
        String toastNo = ActivitySuaGV.this.getResources().getString(R.string.confirmNo);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(toastTittle + giaoVien.getTenGV());
        builder.setMessage(toastMessage + giaoVien.getTenGV());
        builder.setPositiveButton(toastYes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DBChamThi myDB = new DBChamThi(ActivitySuaGV.this);
                myDB.XoaMotItemKH(giaoVien);
                finish();
            }
        });
        builder.setNegativeButton(toastNo, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        builder.create().show();
    }

    private void setControl() {
        edtMaGV = findViewById(R.id.suaMaKH);
        edtTenGV = findViewById(R.id.suaTenKH);
        edtDiaChi = findViewById(R.id.suaDiaChi);
        edtSoDT = findViewById(R.id.suaSoDT);
        btnLuu = findViewById(R.id.save_button_kh);
        btnXoa = findViewById(R.id.delete_button_kh);
    }
    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    //Bấm nút quay về trang danh sách (ko dùng AndroidManifest được vì là từ Fragment về Activity)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
}