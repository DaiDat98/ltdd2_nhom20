package com.example.projectnhom20.GiaoDien;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.projectnhom20.Database.DBChamThi;
import com.example.projectnhom20.Model.MonHoc;
import com.example.projectnhom20.R;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class ActivitySuaMH extends AppCompatActivity {

    EditText edtMaMH, edtTenMH, edtKhoa, edtChiPhi;
    Button btnLuu, btnXoa, btnChooseImg;
    ImageView imgPreviewMH;

    final int REQUEST_CODE_GALLERY = 999;

    MonHoc monHoc = new MonHoc();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sua_mh);
        setControl();
        setEvent();
        layDuLieuMH();

        //Lấy tên cho trang details
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            String titleFormEditSP = ActivitySuaMH.this.getResources().getString(R.string.titleFormEditSP);
            ab.setTitle(titleFormEditSP + " " +  monHoc.getMaMH());
        }

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    private void setEvent() {
        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                suaSanPhamVaoMang();
            }
        });

        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmXoa();
            }
        });

        btnChooseImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(
                        ActivitySuaMH.this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        REQUEST_CODE_GALLERY
                );
            }
        });
    }

    private void suaSanPhamVaoMang() {
        DBChamThi myDB =  new DBChamThi(this);
        final String maMH = edtMaMH.getText().toString();
        final String tenMH = edtTenMH.getText().toString();
        final String khoa = edtKhoa.getText().toString();
        final String chiphi = edtChiPhi.getText().toString();
        final byte[] anhSP = imageViewToByte(imgPreviewMH);

        if(TextUtils.isEmpty(maMH) || TextUtils.isEmpty(tenMH) || TextUtils.isEmpty(khoa)|| TextUtils.isEmpty(chiphi)){
            String toastNull = ActivitySuaMH.this.getResources().getString(R.string.alertNull);
            Toast.makeText(ActivitySuaMH.this, toastNull, Toast.LENGTH_LONG).show();
        }
        else{
            String toastSuccess = ActivitySuaMH.this.getResources().getString(R.string.alertSuccess);
            myDB.SuaSP(new MonHoc(monHoc.getSttSP(),maMH,tenMH,khoa,chiphi, anhSP));
            Toast.makeText(ActivitySuaMH.this, toastSuccess, Toast.LENGTH_LONG).show();
        }
    }


    //Lấy dữ liệu đổ vào trang sửa khi click vào item
    void layDuLieuMH(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("maSP") &&
                getIntent().hasExtra("tenSP") &&
                getIntent().hasExtra("xuatXu") && getIntent().hasExtra("donGia") && getIntent().hasExtra("anhSP")){
            //Getting Data from Intent
            int id = -1;
            monHoc.setSttMH(getIntent().getIntExtra("id",id));
            monHoc.setMaMH(getIntent().getStringExtra("maSP"));
            monHoc.setTenMH(getIntent().getStringExtra("tenSP"));
            monHoc.setKhoa(getIntent().getStringExtra("xuatXu"));
            monHoc.setChiphi(getIntent().getStringExtra("donGia"));
            monHoc.setImageMH(getIntent().getByteArrayExtra("anhSP"));

            //Setting Intent Data
            edtMaMH.setText(monHoc.getMaMH());
            edtTenMH.setText(monHoc.getTenMH());
            edtKhoa.setText(monHoc.getKhoa());
            edtChiPhi.setText(monHoc.getChiphi());

            byte[] anhMH = monHoc.getImageMH();
            Bitmap myImage = BitmapFactory.decodeByteArray(anhMH, 0, anhMH.length);
            imgPreviewMH.setImageBitmap(myImage);
        } else {
            String toastMessage = ActivitySuaMH.this.getResources().getString(R.string.noData);
            Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show();
        }
    }

    void confirmXoa() {
        String toastTittle = ActivitySuaMH.this.getResources().getString(R.string.confirmDeleteTitle);
        String toastMessage = ActivitySuaMH.this.getResources().getString(R.string.confirmDeleteMessage);
        String toastYes = ActivitySuaMH.this.getResources().getString(R.string.confirmYes);
        String toastNo = ActivitySuaMH.this.getResources().getString(R.string.confirmNo);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(toastTittle + monHoc.getTenMH());
        builder.setMessage(toastMessage + monHoc.getTenMH());
        builder.setPositiveButton(toastYes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DBChamThi myDB = new DBChamThi(ActivitySuaMH.this);
                myDB.XoaMotItemSP(monHoc);
                finish();
            }
        });
        builder.setNegativeButton(toastNo, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        builder.create().show();
    }

    public static byte[] imageViewToByte(ImageView image) {
        Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 0, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == REQUEST_CODE_GALLERY){
            if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_CODE_GALLERY);
            }
            else {
                Toast.makeText(getApplicationContext(), "You don't have permission to access file location!", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK && data != null){
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);

                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                imgPreviewMH.setImageBitmap(bitmap);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void setControl() {
        edtMaMH = findViewById(R.id.suaMaSP);
        edtTenMH = findViewById(R.id.suaTenSP);
        edtKhoa = findViewById(R.id.suaXuatXu);
        edtChiPhi = findViewById(R.id.suaDonGia);
        btnLuu = findViewById(R.id.save_button_sp);
        btnXoa = findViewById(R.id.delete_button_sp);

        imgPreviewMH = findViewById(R.id.imgPreviewEditSP);
        btnChooseImg = findViewById(R.id.button_choose_img_editSP);
    }
    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    //Bấm nút quay về trang danh sách (ko dùng AndroidManifest được vì là từ Fragment về Activity)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }
}
