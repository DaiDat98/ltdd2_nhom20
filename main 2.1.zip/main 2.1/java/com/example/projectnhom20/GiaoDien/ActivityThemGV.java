package com.example.projectnhom20.GiaoDien;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projectnhom20.Database.DBChamThi;
import com.example.projectnhom20.Model.GiaoVien;
import com.example.projectnhom20.R;

public class ActivityThemGV extends AppCompatActivity {
    EditText edtMaKH, edtTenKH, edtDiaChi, edtSoDT;
    Button btnThem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_gv);
        setControl();
        setEvent();
        //Đổi tên actionbar theo ngôn ngữ đã đổi:
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.titleFormAddKH));
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    private void setEvent() {
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addKhachHangVaoMang();
            }
        });
    }

    private void addKhachHangVaoMang() {
        DBChamThi myDB = new DBChamThi(this);
        try {
            final String maKH = edtMaKH.getText().toString();
            final String tenKH = edtTenKH.getText().toString();
            final String diaChi = edtDiaChi.getText().toString();
            final String soDT = edtSoDT.getText().toString();

            if(TextUtils.isEmpty(maKH) || TextUtils.isEmpty(tenKH) || TextUtils.isEmpty(diaChi)|| TextUtils.isEmpty(soDT)){
                String toastNull = ActivityThemGV.this.getResources().getString(R.string.alertNull);
                Toast.makeText(ActivityThemGV.this, toastNull, Toast.LENGTH_LONG).show();
            }
            else{
                String toastSuccess = ActivityThemGV.this.getResources().getString(R.string.alertSuccess);
                GiaoVien giaoVien = new GiaoVien(maKH,tenKH,diaChi,soDT);
                Toast.makeText(ActivityThemGV.this, toastSuccess, Toast.LENGTH_LONG).show();
                myDB.ThemKH(giaoVien);
            }
            edtMaKH.setText("");
            edtTenKH.setText("");
            edtDiaChi.setText("");
            edtSoDT.setText("");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setControl() {
        edtMaKH = findViewById(R.id.nhapMaKH);
        edtTenKH = findViewById(R.id.nhapTenKH);
        edtDiaChi = findViewById(R.id.nhapDiaChi);
        edtSoDT = findViewById(R.id.nhapSoDT);
        btnThem = findViewById(R.id.add_button_kh);
    }
    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }

    //Bấm nút quay về trang danh sách (ko dùng AndroidManifest được vì là từ Fragment về Activity)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

}