package com.example.projectnhom20.Model;

public class ChamThi {
    Integer sttCT, soLuongBaiThi;
    String sophieu;
    String maGV;
    String maMH;
    String ngayChamThi;
    String tinhTrangBaiThi;

    public ChamThi() {
    }

    public ChamThi(String sophieu, String maGV, String maMH, Integer soLuongBaiThi, String ngayChamThi, String tinhTrangBaiThi) {
        this.sophieu = sophieu;
        this.maGV = maGV;
        this.maMH = maMH;
        this.soLuongBaiThi = soLuongBaiThi;
        this.ngayChamThi = ngayChamThi;
        this.tinhTrangBaiThi = tinhTrangBaiThi;
    }

    public ChamThi(Integer sttCT, String sophieu, String maGV, String maMH, Integer soLuongBaiThi, String ngayChamThi, String tinhTrangBaiThi) {
        this.sttCT = sttCT;
        this.sophieu = sophieu;
        this.maGV = maGV;
        this.maMH = maMH;
        this.soLuongBaiThi = soLuongBaiThi;
        this.ngayChamThi = ngayChamThi;
        this.tinhTrangBaiThi = tinhTrangBaiThi;
    }

    public Integer getSttCT() { return sttCT; }

    public void setSttCT(Integer sttCT) { this.sttCT = sttCT; }

    public String getSophieu() { return sophieu; }

    public void setSophieu(String sophieu) { this.sophieu = sophieu; }

    public String getMaGV() { return maGV; }

    public void setMaGV(String maGV) { this.maGV = maGV; }

    public String getMaMH() { return maMH; }

    public void setMaMH(String maMH) { this.maMH = maMH; }

    public Integer getSoLuongBaiThi() { return soLuongBaiThi; }

    public void setSoLuongBaiThi(Integer soLuongBaiThi) { this.soLuongBaiThi = soLuongBaiThi; }

    public String getNgayChamThi() { return ngayChamThi; }

    public void setNgayChamThi(String ngayChamThi) { this.ngayChamThi = ngayChamThi; }

    public String getTinhTrangBaiThi() { return tinhTrangBaiThi; }

    public void setTinhTrangBaiThi(String tinhTrangBaiThi) { this.tinhTrangBaiThi = tinhTrangBaiThi; }
}
