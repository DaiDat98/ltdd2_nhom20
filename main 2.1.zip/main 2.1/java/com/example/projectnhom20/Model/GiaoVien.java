package com.example.projectnhom20.Model;

public class GiaoVien {
    String maGV, tenGV,diaChi,soDT;
    Integer sttGV;
    public GiaoVien() {
    }

    public GiaoVien(String maGV, String tenGV, String diaChi, String soDT) {
        this.maGV = maGV;
        this.tenGV = tenGV;
        this.diaChi = diaChi;
        this.soDT = soDT;
    }

    public GiaoVien(Integer sttGV, String maGV, String tenGV, String diaChi, String soDT) {
        this.sttGV = sttGV;
        this.maGV = maGV;
        this.tenGV = tenGV;
        this.diaChi = diaChi;
        this.soDT = soDT;
    }

    public Integer getSttGV() {
        return sttGV;
    }

    public void setSttGV(Integer sttGV) {
        this.sttGV = sttGV;
    }

    public String getMaGV() {
        return maGV;
    }

    public void setMaGV(String maGV) {
        this.maGV = maGV;
    }

    public String getTenGV() {
        return tenGV;
    }

    public void setTenGV(String tenGV) {
        this.tenGV = tenGV;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSoDT() {
        return soDT;
    }

    public void setSoDT(String soDT) {
        this.soDT = soDT;
    }

    @Override
    public String toString() {
        return "KhachHang{" +
                "sttKH='" + sttGV + '\'' +
                ", maKH='" + maGV + '\'' +
                ", tenKH='" + tenGV + '\'' +
                ", diaChi='" + diaChi + '\'' +
                ", soDT='" + soDT + '\'' +
                '}';
    }
}
