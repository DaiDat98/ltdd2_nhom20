package com.example.projectnhom20.Model;

public class MonHoc {
    String maMH, tenMH, khoa, chiphi;
    Integer sttSP;

    byte[] imageMH;

    public MonHoc() {
    }

    public MonHoc(String maMH, String tenMH, String khoa, String chiphi, byte[] imageMH) {
        this.maMH = maMH;
        this.tenMH = tenMH;
        this.khoa = khoa;
        this.chiphi = chiphi;
        this.imageMH = imageMH;
    }

    public MonHoc(Integer sttSP, String maMH, String tenMH, String khoa, String chiphi, byte[] imageMH) {
        this.sttSP = sttSP;
        this.maMH = maMH;
        this.tenMH = tenMH;
        this.khoa = khoa;
        this.chiphi = chiphi;
        this.imageMH = imageMH;
    }

    public MonHoc(String maMH, byte[] imageMH) {
        this.maMH = maMH;
        this.imageMH = imageMH;
    }

    public Integer getSttSP() { return sttSP; }

    public void setSttMH(Integer sttSP) { this.sttSP = sttSP; }
    public String getMaMH() { return maMH; }

    public void setMaMH(String maMH) { this.maMH = maMH; }

    public String getTenMH() { return tenMH; }

    public void setTenMH(String tenMH) { this.tenMH = tenMH; }

    public String getKhoa() { return khoa; }

    public void setKhoa(String khoa) { this.khoa = khoa; }

    public String getChiphi() { return chiphi; }

    public void setChiphi(String chiphi) { this.chiphi = chiphi; }

    public byte[] getImageMH() { return imageMH; }

    public void setImageMH(byte[] imageMH) { this.imageMH = imageMH; }

}
